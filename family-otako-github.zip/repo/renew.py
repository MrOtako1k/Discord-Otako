import os
import json
import urllib.request
import urllib.error
from datetime import datetime, timezone

# ══════════════════════════════════════════════
#  Family Otako — Discord Invite Auto-Renewer
#  يجدد رابط الدعوة كل 5 أيام ويرسل إشعار
# ══════════════════════════════════════════════

BOT_TOKEN      = os.environ["DISCORD_BOT_TOKEN"]       # من GitHub Secrets
CHANNEL_ID     = os.environ["DISCORD_CHANNEL_ID"]      # ID القناة اللي سيُنشأ منها الرابط
WEBHOOK_URL    = os.environ["DISCORD_WEBHOOK_URL"]     # Webhook للإشعار
INVITE_FILE    = "invite.json"

HEADERS_BOT = {
    "Authorization": f"Bot {BOT_TOKEN}",
    "Content-Type": "application/json"
}

def api_request(url, method="GET", data=None, headers=None):
    body = json.dumps(data).encode() if data else None
    req  = urllib.request.Request(url, data=body, headers=headers or {}, method=method)
    try:
        with urllib.request.urlopen(req) as res:
            return json.loads(res.read().decode())
    except urllib.error.HTTPError as e:
        print(f"❌ HTTP Error {e.code}: {e.read().decode()}")
        raise

# ── 1. إنشاء رابط دعوة جديد (صالح 7 أيام، غير محدود الاستخدام) ──
def create_invite():
    print(f"📨 إنشاء رابط دعوة جديد للقناة {CHANNEL_ID}...")
    data = {
        "max_age": 604800,   # 7 أيام بالثواني
        "max_uses": 0,       # غير محدود
        "unique": True
    }
    result = api_request(
        f"https://discord.com/api/v10/channels/{CHANNEL_ID}/invites",
        method="POST",
        data=data,
        headers=HEADERS_BOT
    )
    code = result["code"]
    print(f"✅ الرابط الجديد: https://discord.gg/{code}")
    return code

# ── 2. حفظ الرابط في invite.json ──
def save_invite(code):
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    with open(INVITE_FILE, "w", encoding="utf-8") as f:
        json.dump({"code": code, "updated_at": now}, f, indent=2)
    print(f"💾 تم حفظ الرابط في {INVITE_FILE}")

# ── 3. إرسال إشعار Webhook ──
def notify_webhook(code, updated_at):
    print("📣 إرسال إشعار عبر Webhook...")
    payload = {
        "username": "Family Otako · Link Manager",
        "embeds": [{
            "title": "🔄 تم تجديد رابط الدعوة",
            "description": "تم تحديث رابط السيرفر تلقائياً عبر GitHub Actions",
            "color": 5793266,
            "fields": [
                {
                    "name": "🔗 الرابط الجديد",
                    "value": f"https://discord.gg/{code}",
                    "inline": False
                },
                {
                    "name": "📅 وقت التجديد",
                    "value": updated_at,
                    "inline": True
                },
                {
                    "name": "⏳ التجديد القادم",
                    "value": "بعد 5 أيام",
                    "inline": True
                }
            ],
            "footer": {"text": "Family Otako • نظام إدارة الروابط التلقائي"},
            "timestamp": updated_at
        }]
    }
    req = urllib.request.Request(
        WEBHOOK_URL,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        urllib.request.urlopen(req)
        print("✅ تم إرسال الإشعار بنجاح")
    except Exception as e:
        print(f"⚠️  فشل إرسال الإشعار: {e}")

# ── Main ──
if __name__ == "__main__":
    code       = create_invite()
    now        = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    save_invite(code)
    notify_webhook(code, now)
    print("🎉 اكتمل تجديد الرابط بنجاح!")
